name: Luke Heary
email: ldh4586@rit.edu
date: 12/8/17

To run my implementation of the Robot Attack, follow these steps:

  1. Run the command ./run
  2. You're then prompted for the height, type it in and then hit enter
  3. Then you're prompted for the width, type it in and hit enter
  4. Lastly, you're prompted for the number of robots, type it in and hit enter

  Side note: When you get to this step, the program may run into a segmentation
  fault. If this is the case, then just start from step 1 again. It runs into a
  segmentaiton fault around 20% of the time depending on the size of the grid and
  number of robots and I didn't have time to find it.

  5. The program will then display the entire process of the robots finding the target
  6. Last, you're shown the time it was taken to find the target, as well as how many
     moves it took each robot to get to the target


0 = empty space
1 = the target
2 = other robots
3 = checked spot
